### Hyve: An AI powered Chatbot for WordPress
Contributors: themeisle, hardeepasrani  
Tags: ai, chatbot, openai  
Requires at least: 6.2  
Tested up to: 6.5  
Requires PHP: 7.2  
Stable tag: trunk  
License: GPLv3  
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html  

An AI powered Chatbot for WordPress. You can download the public v1.0.3 version at: [Download hyve.zip](https://github.com/Codeinwp/hyve-v1/raw/main/artifact/hyve.zip)

