<?php
/**
 * Plugin Class.
 *
 * @package Codeinwp\Hyve
 */

namespace ThemeIsle\Hyve;

use ThemeIsle\Hyve\DB_Table, ThemeIsle\Hyve\API;

/**
 * Class Main
 */
class Main {

	/**
	 * Instace of DB_Table class.
	 *
	 * @since 1.0
	 * @var DB_Table
	 */
	public $table;

	/**
	 * Instace of API class.
	 *
	 * @since 1.0
	 * @var API
	 */
	public $api;

	/**
	 * Main constructor.
	 */
	public function __construct() {
		$this->table = new DB_Table();
		$this->api   = new API();

		add_action( 'admin_menu', array( $this, 'register_menu_page' ) );
		add_action( 'save_post', array( $this, 'update_meta' ) );
		add_action( 'delete_post', array( $this, 'delete_post' ) );


		$settings = self::get_settings();

		if (
			is_array( $settings ) &&
			isset( $settings['api_key'] ) && isset( $settings['assistant_id'] ) && isset( $settings['chat_enabled'] ) &&
			! empty( $settings['api_key'] ) && ! empty( $settings['assistant_id'] ) && true === $settings['chat_enabled']
		) {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		}

		add_action( 'init', array( 'ThemeIsle\Hyve\Post_Type', 'register' ) );
	}

	/**
	 * Register menu page.
	 *
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function register_menu_page() {
		$page_hook_suffix = add_menu_page(
			__( 'Hyve', 'hyve' ),
			__( 'Hyve', 'hyve' ),
			'manage_options',
			'hyve',
			array( $this, 'menu_page' ),
			'dashicons-format-chat',
			99
		);

		add_action( "admin_print_scripts-$page_hook_suffix", array( $this, 'enqueue_options_assets' ) );
	}

	/**
	 * Menu page.
	 *
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function menu_page() {
		?>
		<div id="hyve-options"></div>
		<?php
	}

	/**
	 * Load assets for option page.
	 *
	 * @since   1.7.1
	 * 
	 * @return void
	 */
	public function enqueue_options_assets() {
		$asset_file = include HYVE_PATH . '/build/backend/index.asset.php';

		wp_enqueue_style(
			'hyve-styles',
			HYVE_URL . 'build/backend/style-index.css',
			array( 'wp-components' ),
			$asset_file['version']
		);

		wp_enqueue_script(
			'hyve-scripts',
			HYVE_URL . 'build/backend/index.js',
			$asset_file['dependencies'],
			$asset_file['version'],
			true
		);

		wp_set_script_translations( 'hyve-scripts', 'hyve' );

		$post_types        = get_post_types( array( 'public' => true ), 'objects' );
		$post_types_for_js = array();
	
		foreach ( $post_types as $post_type ) {
			$post_types_for_js[] = array(
				'label' => $post_type->labels->name,
				'value' => $post_type->name,
			);
		}

		$settings = self::get_settings();
	
		wp_localize_script(
			'hyve-scripts',
			'hyve',
			array(
				'api'         => $this->api->get_endpoint(),
				'postTypes'   => $post_types_for_js,
				'hasAPIKey'   => isset( $settings['api_key'] ) && ! empty( $settings['api_key'] ),
				'license'     => array(
					'key'        => apply_filters( 'product_hyve_license_key', 'free' ),
					'valid'      => apply_filters( 'product_hyve_license_status', false ),
					'expiration' => self::get_license_expiration_date(),
				),
			)
		);
	}

	/**
	 * Get License Expiration Date.
	 * 
	 * @since 1.0.0
	 * 
	 * @param string $format Date format.
	 * 
	 * @return string|false
	 */
	public static function get_license_expiration_date( $format = 'F Y' ) {
		$option_name = basename( dirname( HYVE_BASEFILE ) );
		$option_name = str_replace( '-', '_', strtolower( trim( $option_name ) ) );
		$data        = get_option( $option_name . '_license_data' );

		if ( isset( $data->expires ) ) {
			$parsed = date_parse( $data->expires );
			$time   = mktime( $parsed['hour'], $parsed['minute'], $parsed['second'], $parsed['month'], $parsed['day'], $parsed['year'] );
			return gmdate( $format, $time );
		}

		return false;
	}

	/**
	 * Get Default Settings.
	 * 
	 * @since 1.0.3
	 * 
	 * @return array
	 */
	public static function get_default_settings() {
		return array(
			'api_key'              => '',
			'chat_enabled'         => true,
			'welcome_message'      => __( 'Hello! How can I help you today?', 'hyve' )
		);
	}

	/**
	 * Get Settings.
	 * 
	 * @since 1.0.3
	 * 
	 * @return array
	 */
	public static function get_settings() {
		$settings = get_option( 'hyve_settings', array() );
		return wp_parse_args( $settings, self::get_default_settings() );
	}

	/**
	 * Enqueue assets.
	 *
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function enqueue_assets() {
		if ( ! apply_filters( 'hyve_enable_chat', true ) ) {
			return;
		}

		$asset_file = include HYVE_PATH . '/build/frontend/frontend.asset.php';

		wp_enqueue_style(
			'hyve-styles',
			HYVE_URL . 'build/frontend/style-index.css',
			array(),
			$asset_file['version']
		);

		wp_enqueue_script(
			'hyve-scripts',
			HYVE_URL . 'build/frontend/frontend.js',
			$asset_file['dependencies'],
			$asset_file['version'],
			true
		);

		wp_set_script_translations( 'hyve-scripts', 'hyve' );

		$settings = self::get_settings();

		$settings = array(
			'api'                 => $this->api->get_endpoint(),
			'audio'               => array(
				'click' => HYVE_URL . 'assets/audio/click.mp3',
				'ping'  => HYVE_URL . 'assets/audio/ping.mp3',
			),
			'welcome'             => $settings['welcome_message'] ?? '',
		);

		wp_localize_script(
			'hyve-scripts',
			'hyve',
			$settings
		);
	}

	/**
	 * Update meta.
	 * 
	 * @param int $post_id Post ID.
	 *
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function update_meta( $post_id ) {
		$added = get_post_meta( $post_id, '_hyve_added', true );

		if ( ! $added ) {
			return;
		}

		update_post_meta( $post_id, '_hyve_needs_update', 1 );
		delete_post_meta( $post_id, '_hyve_moderation_failed' );
		delete_post_meta( $post_id, '_hyve_moderation_review' );
	}

	/**
	 * Delete post.
	 * 
	 * @param int $post_id Post ID.
	 *
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function delete_post( $post_id ) {
		$this->table->delete_by_post_id( $post_id );
	}
}
