=== Hyve: An AI powered Chatbot for WordPress ===
Contributors: themeisle, hardeepasrani
Tags: ai, chatbot, openai
Requires at least: 6.2
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: trunk
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

An AI powered Chatbot for WordPress

== Changelog ==
